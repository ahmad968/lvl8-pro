const express= require("express")
const res = require("express/lib/response")
const app = express()
const  port = 5000


// انشاء ال mongodb
const mongoose = require("mongoose");
mongoose.connect("mongodb://localhost:27017/project9").then(
  () => {
    console.log("DB Ready To Use at project 9");
  },
  (err) => {
    console.log(err);
  }
);

// انشاء ال schema
const userSchema = new mongoose.Schema({
    username: { type: String, required: false },
    email: { type: String, required: true},
    password: { type: String, required: true },
   
  });
const User = mongoose.model("User Model", userSchema);


// بدي اضيف على السكيما 
app.get("/" , (req , res)=>{
    const user = new User({
        username:"dhedaya",
        email: "adhmad",
        password:"dali" ,
    }) 
    user.save()
    .then((result) => {
      res.json(result);
    })
    .catch((err) => {
      res.json(err);
    });
})
// بدي احذف من السكيما 
app.get("/delete" , (req , res)=>{
    User.deleteOne({username:"dhedaya"}).then({

    }).then((result)=>{
        res.json(result)
    }).catch((err)=>{
       res.json(err);
    })
})
// بدي اعدل على السكيما 
app.get("/update", (req , res)=>{
    User.updateOne({email:"ahmad" , email:"hhh"}).then((result)=>{
        res.json(result)
    }).catch((err)=>{
        res.json(err)
    })
})
// اقرأ السكيما 
app.get("/read" , (req , res)=>{
    User.find().then((result)=>{
        res.json(result)
    }).catch((err)=>{
        res.json(err)
    })
})


app.listen(port , ()=>{
    console.log('server working at port 5000');
})
